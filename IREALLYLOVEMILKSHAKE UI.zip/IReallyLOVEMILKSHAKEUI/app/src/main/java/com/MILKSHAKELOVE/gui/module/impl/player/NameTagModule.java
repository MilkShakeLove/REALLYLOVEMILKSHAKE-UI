package com.MILKSHAKELOVE.gui.module.impl.player;

import com.MILKSHAKELOVE.gui.module.Module;
import com.MILKSHAKELOVE.gui.module.ModuleCategory;

public class NameTagModule extends Module {
    public NameTagModule() {
        super("NameTag", ModuleCategory.PLAYER);
    }

    @Override
    protected void onEnable() {

    }

    @Override
    protected void onDisable() {

    }
}
