package com.MILKSHAKELOVE.gui.module.impl.visual;

import com.MILKSHAKELOVE.gui.module.Module;
import com.MILKSHAKELOVE.gui.module.ModuleCategory;

public class DisableModule extends Module {
    public DisableModule() {
        super("Disable", ModuleCategory.VISUAL);
    }

    @Override
    protected void onEnable() {

    }

    @Override
    protected void onDisable() {

    }
}
