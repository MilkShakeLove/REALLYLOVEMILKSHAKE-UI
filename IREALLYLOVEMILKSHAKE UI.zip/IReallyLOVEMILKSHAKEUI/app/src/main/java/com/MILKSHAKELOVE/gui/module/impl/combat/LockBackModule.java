package com.MILKSHAKELOVE.gui.module.impl.combat;

import com.MILKSHAKELOVE.gui.module.Module;
import com.MILKSHAKELOVE.gui.module.ModuleCategory;

public class LockBackModule extends Module {
    public LockBackModule() {
        super("LockBack", ModuleCategory.COMBAT);
    }

    @Override
    protected void onEnable() {

    }

    @Override
    protected void onDisable() {

    }
}
