package com.MILKSHAKELOVE.gui.module;

public interface ModuleToggleListener {
    void onModuleToggled(Module module);
}
