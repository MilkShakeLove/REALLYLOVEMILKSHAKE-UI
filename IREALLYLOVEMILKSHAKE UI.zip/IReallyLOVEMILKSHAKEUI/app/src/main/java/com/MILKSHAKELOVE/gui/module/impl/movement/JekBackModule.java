package com.MILKSHAKELOVE.gui.module.impl.movement;

import com.MILKSHAKELOVE.gui.module.Module;
import com.MILKSHAKELOVE.gui.module.ModuleCategory;

public class JekBackModule extends Module {
    public JekBackModule() {
        super("JekBack", ModuleCategory.MOVEMENT);
    }

    @Override
    protected void onEnable() {

    }

    @Override
    protected void onDisable() {

    }
}
