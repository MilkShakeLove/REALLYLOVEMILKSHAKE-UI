package com.MILKSHAKELOVE.gui.module.impl.player;

import com.MILKSHAKELOVE.gui.module.Module;
import com.MILKSHAKELOVE.gui.module.ModuleCategory;

public class PhasesModule extends Module {
    public PhasesModule() {
        super("Phases", ModuleCategory.PLAYER);
    }

    @Override
    protected void onEnable() {

    }

    @Override
    protected void onDisable() {

    }
}
