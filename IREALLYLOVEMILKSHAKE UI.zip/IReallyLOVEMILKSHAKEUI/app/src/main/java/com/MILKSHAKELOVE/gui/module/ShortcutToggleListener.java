package com.MILKSHAKELOVE.gui.module;

public interface ShortcutToggleListener {
    void onShortcutToggled(Module module, boolean enabled);
}
