package com.MILKSHAKELOVE.gui.module.impl.world;

import com.MILKSHAKELOVE.gui.module.Module;
import com.MILKSHAKELOVE.gui.module.ModuleCategory;

public class AimAssetsModule extends Module {
    public AimAssetsModule() {
        super("AimAssets", ModuleCategory.WORLD);
    }

    @Override
    protected void onEnable() {

    }

    @Override
    protected void onDisable() {

    }
}
