package com.MILKSHAKELOVE.gui.module.impl.combat;

import com.MILKSHAKELOVE.gui.module.Module;
import com.MILKSHAKELOVE.gui.module.ModuleCategory;

public class HitBoxModule extends Module {
    public HitBoxModule() {
        super("HitBox", ModuleCategory.COMBAT);
    }

    @Override
    protected void onEnable() {

    }

    @Override
    protected void onDisable() {

    }
}
