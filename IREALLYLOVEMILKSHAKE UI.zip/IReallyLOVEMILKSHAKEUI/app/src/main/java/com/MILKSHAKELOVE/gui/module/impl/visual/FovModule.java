package com.MILKSHAKELOVE.gui.module.impl.visual;

import com.MILKSHAKELOVE.gui.module.Module;
import com.MILKSHAKELOVE.gui.module.ModuleCategory;

public class FovModule extends Module {
    public FovModule() {
        super("Fov", ModuleCategory.VISUAL);
    }

    @Override
    protected void onEnable() {

    }

    @Override
    protected void onDisable() {

    }
}
