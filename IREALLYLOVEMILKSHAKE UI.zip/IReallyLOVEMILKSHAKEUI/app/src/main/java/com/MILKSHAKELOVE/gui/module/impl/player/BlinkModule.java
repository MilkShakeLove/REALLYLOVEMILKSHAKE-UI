package com.MILKSHAKELOVE.gui.module.impl.player;

import com.MILKSHAKELOVE.gui.module.Module;
import com.MILKSHAKELOVE.gui.module.ModuleCategory;

public class BlinkModule extends Module {
    public BlinkModule() {
        super("Blink", ModuleCategory.PLAYER);
    }

    @Override
    protected void onEnable() {

    }

    @Override
    protected void onDisable() {

    }
}
