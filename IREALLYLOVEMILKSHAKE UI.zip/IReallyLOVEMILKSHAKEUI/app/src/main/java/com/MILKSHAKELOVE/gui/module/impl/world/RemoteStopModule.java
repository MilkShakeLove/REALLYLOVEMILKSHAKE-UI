package com.MILKSHAKELOVE.gui.module.impl.world;

import com.MILKSHAKELOVE.gui.module.Module;
import com.MILKSHAKELOVE.gui.module.ModuleCategory;

public class RemoteStopModule extends Module {
    public RemoteStopModule() {
        super("RemoteStop", ModuleCategory.WORLD);
    }

    @Override
    protected void onEnable() {

    }

    @Override
    protected void onDisable() {

    }
}
